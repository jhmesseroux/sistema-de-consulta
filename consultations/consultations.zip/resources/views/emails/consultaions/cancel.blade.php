@component('mail::message')
    # Introduction
    @component('mail::button', ['url' => ''])
        Button Text
    @endcomponent
    hanks,<br>
@endcomponent
