<x-app-layout>

    <x-slot name="header">
        <span class="font-bold text-gray-700">
            Consultas
        </span>
    </x-slot>
    <br />

    @include('consultation.index')

</x-app-layout>
