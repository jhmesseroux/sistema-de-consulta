<x-app-layout>
    <x-slot name="header">
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl space-y-3 mx-auto sm:px-6 lg:px-8">
            {{-- <div class="bg-white overflow-hidden shadow-sm sm:rounded">
                <div class="p-6 bg-white border-b border-gray-200">
                  <span class="gradient form-title"> Novedades</span>
                </div>
            </div> --}}
            <div class="bg-white overflow-hidden shadow-sm sm:rounded">
                <div class="p-6 bg-white border-b border-gray-200">
                    <span class="gradient form-title mb-0"> Proximas Consultas </span>
                </div>
                <ul class="flex gap-4 p-4 bg-gray-100 items-center justify-center">
                    @foreach ($nextMeetings as $meet)
                        <li
                            class="flex border-b-2  overflow-hidden !w-60 cursor-pointer border-b-blue-500 flex-col p-6 gap-2  hover:bg-blue-600 hover:text-white  rounded shadow-md bg-white hover:shadow-lg
                     transition-shadow text-gray-900 duration-300 ">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 text-blue-500 " viewBox="0 0 20 20"
                                fill="currentColor">
                                <path
                                    d="M10 2a6 6 0 00-6 6v3.586l-.707.707A1 1 0 004 14h12a1 1 0 00.707-1.707L16 11.586V8a6 6 0 00-6-6zM10 18a3 3 0 01-3-3h6a3 3 0 01-3 3z" />
                            </svg>
                            <span class="capitalize">
                                {{ $meet->consultation->subject->name }} : {{ $meet->consultation->time }}
                            </span>
                            <span>

                                Salon :
                                {{ $meet->consultation->place ?? '--' }}
                            </span>
                            <span>
                                {{ Str::limit($meet->comment, 20, '...') }}
                            </span>
                        </li>
                    @endforeach
                </ul>
            </div>

        </div>
    </div>

</x-app-layout>
