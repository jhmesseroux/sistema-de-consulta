<td {{ $attributes(['class' => 'text-sm pr-6 whitespace-no-wrap text-gray-800  tracking-normal leading-4']) }}>
    {{ $slot }}
</td>
