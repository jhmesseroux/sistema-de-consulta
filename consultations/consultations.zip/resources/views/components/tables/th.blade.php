@props(['text'])
<th role="columnheader"
    {{ $attributes(['class' => 'text-gray-800 0 font-bold pr-6 text-left text-sm tracking-normal leading-4']) }}>
    {{ $text }}
</th>
