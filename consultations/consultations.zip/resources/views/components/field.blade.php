<div class="mt-4">
    {{ $slot }}
</div>
