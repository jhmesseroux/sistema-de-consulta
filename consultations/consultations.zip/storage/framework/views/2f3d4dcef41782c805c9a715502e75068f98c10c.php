<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?>  <?php $__env->endSlot(); ?>

    <div class="container mx-auto w-9/12   my-6">

        <div class="lg:flex h-fit">
            <div
                class="xl:w-2/5 lg:w-2/5 !min-h-full via-blue-500 bg-blue-600 py-16 xl:rounded-bl rounded-tl rounded-tr xl:rounded-tr-none">
                <div class="xl:w-5/6 xl:px-0 px-8 mx-auto">
                    <h1 class="xl:text-4xl text-3xl pb-4 text-white font-bold">Contacto</h1>
                    <p class="text-xl text-white pb-8 leading-relaxed font-normal lg:pr-4">
                        ¿Tiene alguna duda? No dudes en contactarnos o escribirnos un mensaje.
                    </p>
                    <div class="flex pb-4 items-center">
                        <div aria-label="phone icon" role="img">
                            <img src="https://tuk-cdn.s3.amazonaws.com/can-uploader/contact_indigo-svg1.svg"
                                alt="phone" />

                        </div>
                        <p class="pl-4 text-white text-base">+54 9 341 101 1010</p>
                    </div>
                    <div class="flex items-center">
                        <div aria-label="email icon" role="img">
                            <img src="https://tuk-cdn.s3.amazonaws.com/can-uploader/contact_indigo-svg2.svg"
                                alt="email" />

                        </div>
                        <p class="pl-4 text-white text-base">sdcutn2022@gmail.com</p>
                    </div>
                    <p class="text-lg text-white pt-10 tracking-wide">
                        Zeballos 1247
                        <br />
                        Rosario , Santa Fe
                    </p>
                    
                </div>
            </div>
            <div class="xl:w-3/5 lg:w-3/5 bg-gray-200 h-full xl:pl-0 rounded-tr rounded-br">
               
                <form id="contact" action="/admin/contact" method="POST"
                    class="bg-white  py-4 px-8 rounded-tr rounded-br">

                    <?php echo csrf_field(); ?>

                     <?php if(Session::get('success')): ?>
                    <div
                        class="text-green-600 p-4 border  my-4 rounded-sm shadow-sm bg-green-200"><?php echo e(Session::get('success')); ?></div>
                <?php endif; ?>
                    
                    <div class="block xl:flex flex-col w-full flex-wrap justify-between mb-6">
                        <div class="w-2/4 max-w-xs mb-6 xl:mb-0">
                            <div class="flex flex-col">
                                <label for="full_name"
                                    class="text-gray-800 text-sm font-semibold leading-tight tracking-normal mb-2">Nombre
                                    Completo</label>
                                <input required id="fullname" name="fullname" type="text"
                                    class=" focus:outline-none focus:border focus:border-indigo-700 font-normal w-64 h-10 flex items-center pl-3 text-sm border-gray-300 rounded border"
                                    placeholder="Nombre Completo" aria-label="Nombre completo por favor" />
                                <?php $__errorArgs = ['fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-400 text-xs p-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                    </div>
                    <div class="flex w-full flex-wrap mb-6">
                        <div class="w-2/4 max-w-xs">
                            <div class="flex flex-col">
                                <label for="email"
                                    class="text-gray-800  text-sm font-semibold leading-tight tracking-normal mb-2">Mail</label>
                                <input required id="email" name="email" type="email"
                                    :value="Auth::user() ? Auth::user()->email : old('email')"
                                    class=" focus:outline-none focus:border focus:border-indigo-700 font-normal w-64 h-10 flex items-center pl-3 text-sm border-gray-300 rounded border"
                                    placeholder="example@gmail.com" aria-label="enter your phone number input" />
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-400 text-xs p-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="flex w-full flex-wrap mb-6">
                        <div class="w-2/4 max-w-xs">
                            <div class="flex flex-col">
                                <label for="phone"
                                    class="text-gray-800  text-sm font-semibold leading-tight tracking-normal mb-2">Celular</label>
                                <input required id="phone" name="phone" type="tel"
                                    class=" focus:outline-none focus:border focus:border-indigo-700 font-normal w-64 h-10 flex items-center pl-3 text-sm border-gray-300 rounded border"
                                    placeholder="+54 9 341 111 0990" aria-label="Ingrese su numero de telefono" />
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-400 text-xs p-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="w-full mt-6">
                        <div class="flex flex-col">
                            <label class="text-sm font-semibold   mb-2" for="message">Message</label>
                            <textarea placeholder="" name="message"
                                class="border-gray-300 border mb-4 rounded py-2 text-sm outline-none resize-none px-3 focus:border focus:border-indigo-700"
                                rows="6" id="message" aria-label="enter your message input"></textarea>
                            <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-400 text-xs p-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => []]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                            Enviar
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH D:\UTN_4_YEAR\Entornos-graficos\tpfinal\consultations\resources\views/contact.blade.php ENDPATH**/ ?>