<footer class="p-4 bg-blue-600 text-white shadow md:px-6 md:py-8 ">
    <div class="sm:flex sm:items-center sm:justify-between">
        <a href="/" title="Ir al inicio" class="flex items-center mb-4 sm:mb-0 w-[fit-content]">
            <img src="https://res.cloudinary.com/draxircbk/image/upload/v1653327438/sdc%20utn%202022/Eco_Home_Real_Estate_Logo_nnwggi.png"
                alt="Sistema de Consulta UTN" width="200">
            
        </a>
        <ul class="flex flex-wrap items-center mb-6 mr-4 text-sm  sm:mb-0 ">
            <li>
                <a href="/" class="mr-4 hover:underline md:mr-6 ">Inicio</a>
            </li>
            
            <li>
                <a href="/contact" class="hover:underline">Contacto</a>
            </li>
        </ul>
    </div>
    <hr class="my-6 border-gray-200 sm:mx-auto  lg:my-8">
    <span class="block text-sm  sm:text-center ">© 2022 <a href="/" class="hover:underline">SDC UTN™</a>. Todos
        los derechos reservados.
    </span>
</footer>


<?php /**PATH D:\UTN_4_YEAR\Entornos-graficos\tpfinal\consultations\resources\views/components/guest-footer.blade.php ENDPATH**/ ?>