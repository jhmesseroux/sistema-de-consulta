<?php $__env->startComponent('mail::message'); ?>
# Bienvenido <?php echo e($user->lastname); ?>

Bienvenido a SDC UTN ,
estamos para ayudarte a lo largo del cursado . Puede visitar tu perfil con este boton 👇👇,
<?php echo e($link = 'hello'); ?>

<?php $__env->startComponent('mail::button', ['url' => 'https://sdcutn2022.herokuapp.com/user/'.$user->dni]); ?>
 Visitar Perfil
<?php echo $__env->renderComponent(); ?>
si no funciona usa este link <a href="https://sdcutn2022.herokuapp.com/"> https://sdcutn2022.herokuapp.com/user/<?php echo e($user->dni); ?></a><br><br><br>
Gracias
<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\UTN_4_YEAR\Entornos-graficos\tpfinal\consultations\resources\views/emails/welcome.blade.php ENDPATH**/ ?>