<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\UTN_4_YEAR\Entornos-graficos\tpfinal\consultations\resources\views/vendor/mail/text/button.blade.php ENDPATH**/ ?>