


<?php if($avatar): ?>
<img class="w-8 h-8 rounded-full" src="<?php echo e(asset('storage/' . $avatar)); ?>"
    alt="<?php echo e($altenative); ?>">
<?php else: ?>
<img class="rounded-full  shadow-sm border-2 border-gray-2 w-9 h-9"
    src="<?php echo e(asset('storage/avatars/default-avatar.png')); ?>"
    alt=" <?php echo e($alternative); ?>">
<?php endif; ?>
<?php /**PATH D:\UTN_4_YEAR\Entornos-graficos\tpfinal\consultations\resources\views/components/avatarIcon.blade.php ENDPATH**/ ?>