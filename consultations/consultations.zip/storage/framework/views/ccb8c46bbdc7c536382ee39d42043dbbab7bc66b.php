<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        Resultado(s) para
        <span class="font-bold text-gray-700">
            <?php echo e(request('search')); ?> (<?php echo e($consultations->count()); ?>)
        </span>
     <?php $__env->endSlot(); ?>

    

    <div id="confirm-condultation-modal" tabindex="-1" aria-hidden="true"
        class="overflow-y-auto hidden flex overflow-x-hidden fixed bg-overlay top-0 right-0 left-0 z-50 w-full min-h-screen md:inset-0 h-modal md:h-full justify-center items-center">
        <div class="relative p-4 w-full max-w-md h-full md:h-auto">
            <div class="relative bg-gray-100 shadow-md ">
                <div class="flex justify-end p-2">
                    <button onclick="closeModal()" type="button"
                        class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center dark:hover:bg-gray-800 dark:hover:text-white"
                        data-modal-toggle="authentication-modal">
                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                            xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd"
                                d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                clip-rule="evenodd"></path>
                        </svg>
                    </button>
                </div>
                <form action="/meeting/save" method="POST" id="reserva-consultation"
                    class="px-6 pb-4 space-y-6 lg:px-8 sm:pb-6 xl:pb-8">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="dateConsultation" id="dateConsultation">
                    <h3 class="text-xl font-medium text-gray-900 ">Confirma tu consulta</h3>
                    <div>
                        <label for="comment" class="block mb-2 text-sm font-medium text-gray-900 ">
                            Descripcion
                        </label>
                        <textarea onkeyup="updateCounter()" minlength="5" type="text" name="comment" id="comment" 
                            class="bg-gray-50 h-20 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 "
                            placeholder="breve descripcion de la duda" required="" focus></textarea>
                        <div class="flex justify-between items-center">
                            <span id="comment-error" class="text-red-300 hidden p-1">Debe entre 5 a 100 caracteres!
                            </span>
                            <span class="self-end">
                                <span id="counter" class="">0</span>
                                <span>
                                    /100
                                </span>
                            </span>
                        </div>
                    </div>
                    <div class="flex gap-4 justify-end items-center self-end flex-end">

                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['class' => '!bg-gray-100 duration-200 hover:!bg-gray-300 !text-gray-700','type' => 'button']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => '!bg-gray-100 duration-200 hover:!bg-gray-300 !text-gray-700','type' => 'button']); ?>
                            Cancelar
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['id' => 'confirm','type' => 'submit']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'confirm','type' => 'submit']); ?>
                            Confirma
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                    </div>

                </form>
            </div>
        </div>
    </div>


    <?php if($consultations->count()): ?>
        <ul role="list" class="container m-auto divide-y my-4 p-4  divide-gray-300 ">
            <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="p-2 text-red-500 my-4"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php $__currentLoopData = $consultations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                
                <li
                    class="result-search-item p-3 sm:py-4 bg-white shadow hover:shadow-lg hover:rounded-sm cursor-pointer duration-300 hover:bg-blue-600 hover:!text-white ">
                    <div class="flex gap-2 sm:items-center sm:flex-row flex-col sm:space-x-4">


                        <div class="flex-shrink-0 flex items-center  gap-1">
                            <?php if($con->avatar): ?>
                                <img class="w-8 h-8 rounded-full" src="<?php echo e(asset('storage/' . $con->avatar)); ?>"
                                    alt=" <?php echo e($con->firstname . $con->lastname); ?>">
                            <?php else: ?>
                                <img class="rounded-full  shadow-sm border-2 border-gray-2 w-9 h-9"
                                    src="<?php echo e(asset('storage/avatars/default-avatar.png')); ?>"
                                    alt=" <?php echo e($con->firstname . $con->lastname); ?>">
                            <?php endif; ?>
                            <div class="flex-1 min-w-0">
                                <p class="text-sm font-medium text-gray-900 truncate">
                                    <?php echo e($con->firstname); ?>

                                </p>
                                <p class="text-sm text-gray-500 truncate ">
                                    <?php echo e($con->email); ?>

                                </p>
                            </div>

                        </div>
                        
                        <div class="flex-1 min-w-0">
                            <p class="text-sm font-medium capitalize text-gray-900 truncate">
                                <?php echo e($con->name); ?>

                            </p>
                            <p class="text-sm text-gray-500 truncate ">
                                <?php echo e($con->dayOfWeek); ?> <?php echo e($con->diaDeConsulta); ?> |
                                <?php echo e($con->time); ?>

                            </p>
                            <p class="text-sm text-gray-500 truncate ">
                                Salon :
                                <?php echo e($con->place); ?>

                            </p>
                        </div>
                        <div class="inline-flex items-center text-base font-semibold text-gray-900 ">
                            
                            <?php if($con->active): ?>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['type' => 'button','onclick' => 'dothat('.e($con->id).',\''.e($con->dateConsultation).'\')']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'button','onclick' => 'dothat('.e($con->id).',\''.e($con->dateConsultation).'\')']); ?>
                                    Reservar
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            <?php else: ?>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['class' => 'bg-red-500','type' => 'button','disabled' => true]]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'bg-red-500','type' => 'button','disabled' => true]); ?>
                                    Supendido
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php if(!$con->active): ?>
                        <div class="reason-cancel">
                            <span class="p-1 text-sm text-red-300"> Esta consulta está suspendida por el momento!
                            </span>
                        </div>
                    <?php endif; ?>
                    

                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="my-4 p-2">
                <?php echo e($consultations->links()); ?>

            </div>

        </ul>
    <?php else: ?>
        <div class="container flex w-full items-center justify-center p-6 m-4">
            <p class="bg-gray-200 border-l-4 border-red-500 p-4 w-4/5">No hay resultado para <strong>
                    <?php echo e(request('search')); ?>. </strong>
                Volver al <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['class' => 'text-blue-500','href' => '/']]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'text-blue-500','href' => '/']); ?>Inicio <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </p>
        </div>
    <?php endif; ?>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH D:\UTN_4_YEAR\Entornos-graficos\tpfinal\consultations\resources\views/consultation/search.blade.php ENDPATH**/ ?>