<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin','data' => []]); ?>
<?php $component->withName('admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

     <?php $__env->slot('header', null, []); ?> 
        <span class="font-bold text-gray-700">
            Consultas canceladas
        </span>
     <?php $__env->endSlot(); ?>
    <br />

    <main>

        <main class=" flex justify-center">

            <div class=" container bg-white  p-6 ">
                
                <h1 class="text-xl pb-4">Consultas canceladas de: <b class="text-xl font-medium pb-4"><?php echo e($profesor['firstname']); ?>

                    <?php echo e($profesor['lastname']); ?></b> </h1>
                <div class="   ">
                    <?php if($profesor['avatar']): ?>
                        <img class="w-8 h-8 rounded-full" src="<?php echo e(asset('storage/' . $profesor['avatar'])); ?>"
                    alt="foto del profesor <?php echo e($profesor['firstname'] .$profesor['lastname']); ?>">
                    <?php else: ?>
                    <img class="rounded-full  shadow-sm border-2 border-gray-2 w-9 h-9"
                        src="<?php echo e(asset('storage/avatars/default-avatar.png')); ?>"
                        alt="foto del profesor <?php echo e($profesor['firstname'] .$profesor['lastname']); ?>">
                    <?php endif; ?>
                    <div class="">
                        <p class="text-base text-gray-500 truncate ">
                            <?php echo e($profesor['email']); ?>

                        </p>
                    </div>
                    <br>
                    <br>

                    <?php $__currentLoopData = $consultas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="">
                        <p class="text-lg font-medium capitalize text-gray-900 truncate">
                            <?php echo e($item->name); ?>

                        </p>
                        <p class="text-base text-gray-500 truncate ">
                            <?php echo e($item->dayOfWeek); ?> |
                            <?php echo e($item->time); ?> | Salón: <?php echo e($item->place); ?>

                        </p>
                        <p class="text-sm text-gray-500 truncate ">

                        </p>
                    </div>
                    <div class=" w-full overflow-x-auto xl:overflow-x-hidden">
                        <table class="min-w-full text-gray-800 bg-white">
                            <thead>
                                <tr class="w-full h-16 border-gray-300 border-b py-8">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.tables.th','data' => ['text' => 'Dia','class' => 'pl-4']]); ?>
<?php $component->withName('tables.th'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text' => 'Dia','class' => 'pl-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.tables.th','data' => ['text' => 'Motivo']]); ?>
<?php $component->withName('tables.th'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text' => 'Motivo']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $item->razones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $razon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="p-6  h-10 border-gray-300 border-b">

                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.tables.td','data' => ['class' => 'pl-4  pb-3','style' => 'width:20%']]); ?>
<?php $component->withName('tables.td'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'pl-4  pb-3','style' => 'width:20%']); ?> <?php echo e($razon->created_at); ?>

                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.tables.td','data' => ['class' => 'pb-3']]); ?>
<?php $component->withName('tables.td'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'pb-3']); ?><?php echo e($razon->reasonCancel); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                                </tr>


                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <br />
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </main>
    </main>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH D:\UTN_4_YEAR\Entornos-graficos\tpfinal\consultations\resources\views/reasonCancel/information.blade.php ENDPATH**/ ?>