<?php echo e($slot); ?>

<?php /**PATH D:\UTN_4_YEAR\Entornos-graficos\tpfinal\consultations\resources\views/vendor/mail/text/panel.blade.php ENDPATH**/ ?>