<?php $__env->startComponent('mail::message'); ?>
# En Hora buena <?php echo e($meet->user->lastname); ?>

Tu consulta se reservo con exito para el dia <?php echo e($meet->consultation->dayOfWeek); ?>


Materia : <?php echo e($meet->consultation->subject->name); ?>


Hora : <?php echo e($meet->consultation->time); ?>


Salon : <?php echo e($meet->consultation->place); ?>


Profesor : <?php echo e($meet->consultation->teacher->lastname); ?> <?php echo e($meet->consultation->teacher->firstname); ?> |  <?php echo e($meet->consultation->teacher->email); ?>


<?php $__env->startComponent('mail::button', ['url' => 'https://sdcutn2022.herokuapp.com/meeting/user']); ?>
Ver mis consultas
<?php echo $__env->renderComponent(); ?>

Gracias
<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\UTN_4_YEAR\Entornos-graficos\tpfinal\consultations\resources\views/emails/consultation.blade.php ENDPATH**/ ?>