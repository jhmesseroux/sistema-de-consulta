<img title="Sistema de Consulta UTN"
    src="https://res.cloudinary.com/draxircbk/image/upload/v1653326573/sdc%20utn%202022/logo_lyig5s.png" width="80"
    alt="LOGO ">
<?php /**PATH D:\UTN_4_YEAR\Entornos-graficos\tpfinal\consultations\resources\views/components/application-logo.blade.php ENDPATH**/ ?>