<img title="Ir al inicio"
    src="https://res.cloudinary.com/draxircbk/image/upload/v1653326573/sdc%20utn%202022/logo_lyig5s.png" width="80"
    alt="Sistema de Consulta UTN">
<?php /**PATH D:\UTN_4_YEAR\Entornos-graficos\tpfinal\consultations\resources\views/components/application-logo.blade.php ENDPATH**/ ?>