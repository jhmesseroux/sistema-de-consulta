<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl space-y-3 mx-auto sm:px-6 lg:px-8">
            
            <div class="bg-white overflow-hidden shadow-sm sm:rounded">
                <div class="p-6 bg-white border-b border-gray-200">
                    <span class="gradient form-title mb-0"> Proximas Consultas </span>
                </div>
                <ul class="flex gap-4 p-4 bg-gray-100 items-center justify-center">
                    <?php $__currentLoopData = $nextMeetings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li
                            class="flex border-b-2  overflow-hidden !w-60 cursor-pointer border-b-blue-500 flex-col p-6 gap-2  hover:bg-blue-600 hover:text-white  rounded shadow-md bg-white hover:shadow-lg
                     transition-shadow text-gray-900 duration-300 ">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 text-blue-500 " viewBox="0 0 20 20"
                                fill="currentColor">
                                <path
                                    d="M10 2a6 6 0 00-6 6v3.586l-.707.707A1 1 0 004 14h12a1 1 0 00.707-1.707L16 11.586V8a6 6 0 00-6-6zM10 18a3 3 0 01-3-3h6a3 3 0 01-3 3z" />
                            </svg>
                            <span class="capitalize">
                                <?php echo e($meet->consultation->subject->name); ?> : <?php echo e($meet->consultation->time); ?>

                            </span>
                            <span>

                                Salon :
                                <?php echo e($meet->consultation->place ?? '--'); ?>

                            </span>
                            <span>
                                <?php echo e(Str::limit($meet->comment, 20, '...')); ?>

                            </span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH D:\UTN_4_YEAR\Entornos-graficos\tpfinal\consultations\resources\views/dashboard.blade.php ENDPATH**/ ?>