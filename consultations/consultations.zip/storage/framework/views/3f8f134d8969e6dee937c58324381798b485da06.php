<td <?php echo e($attributes(['class' => 'text-sm pr-6 whitespace-no-wrap text-gray-800  tracking-normal leading-4'])); ?>>
    <?php echo e($slot); ?>

</td>
<?php /**PATH D:\UTN_4_YEAR\Entornos-graficos\tpfinal\consultations\resources\views/components/tables/td.blade.php ENDPATH**/ ?>