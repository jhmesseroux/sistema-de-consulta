<?php $__env->startComponent('mail::message'); ?>
    # Introduction
    <?php $__env->startComponent('mail::button', ['url' => '']); ?>
        Button Text
    <?php echo $__env->renderComponent(); ?>
    hanks,<br>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\UTN_4_YEAR\Entornos-graficos\tpfinal\consultations\resources\views/emails/consultaions/cancel.blade.php ENDPATH**/ ?>