<?php $__env->startComponent('mail::message'); ?>
# Cancelacion de consulta
La consulta de <?php echo e($subject); ?> del dia <?php echo e($dateCon); ?> fue cancelada . 
Gracias,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\UTN_4_YEAR\Entornos-graficos\tpfinal\consultations\resources\views/emails/consultaions/cancel.blade.php ENDPATH**/ ?>