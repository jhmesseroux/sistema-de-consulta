<div class="subject-create">

        <input type="hidden" value="<?php echo e(isset($subject->id)? $subject->id: ''); ?>" name="id" id="id">

        <fieldset>
            <label for="name">Nombre</label>
            <input type="text" id="name" value="<?php echo e(isset($subject->name)? $subject->name : ''); ?>" name="name" id="name" placeholder="Ingrese un nombre">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.errorInput','data' => ['name' => 'name']]); ?>
<?php $component->withName('errorInput'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'name']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </fieldset>

        <button type="submit">Editar</button>

</div>
<?php /**PATH D:\UTN_4_YEAR\Entornos-graficos\tpfinal\consultations\resources\views/subject/form.blade.php ENDPATH**/ ?>