<div class="min-h-screen flex flex-col sm:justify-center items-center bg-gray-200 pt-6 sm:pt-0 ">
    <div>
        <?php echo e($logo); ?>

    </div>

    <div class="bg-white sm:max-w-md mt-6 px-6 py-4 m-4  shadow-md overflow-hidden rounded ">
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH D:\UTN_4_YEAR\Entornos-graficos\tpfinal\consultations\resources\views/components/auth-card.blade.php ENDPATH**/ ?>