<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\UTN_4_YEAR\Entornos-graficos\tpfinal\consultations\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>