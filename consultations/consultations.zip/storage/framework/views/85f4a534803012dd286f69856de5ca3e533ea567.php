<?php $__env->startComponent('mail::message'); ?>
# Consultas de <?php echo e($fullname); ?>


<?php echo e($message); ?>


Contesta al <span class="text-blue-600"><?php echo e($email); ?></span> 

Gracias,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\UTN_4_YEAR\Entornos-graficos\tpfinal\consultations\resources\views/emails/contact.blade.php ENDPATH**/ ?>