<?php $__env->startComponent('mail::message'); ?>
    # Bienvenido <?php echo e($user->lastname); ?>


    Lorem ipsum dolor sit, amet consectetur adipisicing elit. Iste minus laboriosam aut libero? Sed atque veniam quos cum.
    Eum, cumque.
    <ul>
        <li>one</li>
        <li>two</li>
        <li>Three</li>
    </ul>
    <?php $__env->startComponent('mail::button', ['url' => '/']); ?>
        Ver Perfil
    <?php echo $__env->renderComponent(); ?>

    CEO,<br> Jean Hilaire Messeroux
<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\UTN_4_YEAR\Entornos-graficos\tpfinal\consultations\resources\views/users/welcome.blade.php ENDPATH**/ ?>