<?php echo e($slot); ?>

<?php /**PATH D:\UTN_4_YEAR\Entornos-graficos\tpfinal\consultations\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>