<tr>
    <td class="header">
        <a href="<?php echo e($url); ?>" style="display: inline-block;">
            <?php if(trim($slot) === 'Laravel'): ?>
                <img src="https://res.cloudinary.com/draxircbk/image/upload/v1653326573/sdc%20utn%202022/sdcutnwithnames_e2kyxc.png" class="logo" alt="SDC UTN 2022">
            <?php else: ?>
                <?php echo e($slot); ?>

            <?php endif; ?>
        </a>
    </td>
</tr>
<?php /**PATH D:\UTN_4_YEAR\Entornos-graficos\tpfinal\consultations\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>