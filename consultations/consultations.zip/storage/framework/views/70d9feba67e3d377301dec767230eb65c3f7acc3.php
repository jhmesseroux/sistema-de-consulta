<div class="mt-4">
    <?php echo e($slot); ?>

</div>
<?php /**PATH D:\UTN_4_YEAR\Entornos-graficos\tpfinal\consultations\resources\views/components/field.blade.php ENDPATH**/ ?>