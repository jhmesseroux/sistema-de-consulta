
<?php if(isset($consultation)): ?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.form_consultation','data' => ['teachers' => $teachers,'subjects' => $subjects,'modo' => $modo,'consultation' => $consultation,'week' => $week]]); ?>
<?php $component->withName('form_consultation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['teachers' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($teachers),'subjects' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($subjects),'modo' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($modo),'consultation' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($consultation),'week' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($week)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php else: ?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.form_consultation','data' => ['teachers' => $teachers,'subjects' => $subjects,'modo' => $modo,'week' => $week]]); ?>
<?php $component->withName('form_consultation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['teachers' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($teachers),'subjects' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($subjects),'modo' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($modo),'week' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($week)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php endif; ?>
<?php /**PATH D:\UTN_4_YEAR\Entornos-graficos\tpfinal\consultations\resources\views/consultation/form.blade.php ENDPATH**/ ?>