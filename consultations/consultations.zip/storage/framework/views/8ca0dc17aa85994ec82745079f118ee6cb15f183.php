<div class="role-remove">
  <p><b>¿Seguro que deseas borrar el rol que posee los siguientes datos?</b></p>
  <form action="/admin/role/delete" method="post">
    <?php echo csrf_field(); ?>
    <fieldset>
      <input type="hidden" value="<?php echo e($role->id); ?>" name="id" id="id">
      <label for="name">Nombre</label>
      <input type="text" value="<?php echo e($role->name); ?>" name="nombre" id="name" disabled>
      <label for="description">Descripcion</label>
      <input type="text" value="<?php echo e($role->description); ?>" name="descripcion" id="description" disabled>
    </fieldset>
    <button type="submit">Sí, borrar</button>
  </form>
  <a href="/admin/roles">No, volver</a>
</div>
<?php /**PATH D:\UTN_4_YEAR\Entornos-graficos\tpfinal\consultations\resources\views/role/remove.blade.php ENDPATH**/ ?>